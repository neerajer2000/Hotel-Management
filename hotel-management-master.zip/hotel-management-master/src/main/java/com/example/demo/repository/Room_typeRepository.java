package com.example.demo.repository;

import com.example.demo.model.Room_type;
import org.springframework.data.repository.CrudRepository;

public interface Room_typeRepository extends CrudRepository<Room_type, Long> {
}
